-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: dsba_6160_project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locationinfo`
--

DROP TABLE IF EXISTS `locationinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locationinfo` (
  `index` bigint DEFAULT NULL,
  `id` bigint DEFAULT NULL,
  `first name` text,
  `last name` text,
  `email` text,
  `address` text,
  `city` text,
  `postalZip` bigint DEFAULT NULL,
  `region` text,
  `country` text,
  `LocationId` bigint DEFAULT NULL,
  KEY `ix_locationinfo_index` (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locationinfo`
--

LOCK TABLES `locationinfo` WRITE;
/*!40000 ALTER TABLE `locationinfo` DISABLE KEYS */;
INSERT INTO `locationinfo` VALUES (0,1503960366,'Brittne','Di Bernardo','erat@google.com','Ap #592-6588 Cubilia Avenue','Newport News',91134,'Kansas','United States',1),(1,1624580081,'Idalia','Sweedland','vitae.odio@hotmail.com','P.O. Box 113, 6368 Nulla Rd.','Montpelier',57831,'Virginia','United States',2),(2,1644430081,'Katha','Martinho','sit.amet@icloud.edu','654-3719 Auctor Street','South Portland',79341,'Florida','United States',3),(3,1844505072,'Brittan','Rookwell','laoreet.libero@yahoo.couk','Ap #618-1973 Quis, Av.','Baton Rouge',98807,'Washington','United States',4),(4,1927972279,'Kristofor','Jurgensen','aliquam@aol.com','1011 Vestibulum Rd.','Burlington',36891,'Alabama','United States',5),(5,2022484408,'Arlette','Fitch','eu.eleifend@aol.edu','974-7501 Adipiscing. St.','Phoenix',27365,'Iowa','United States',6),(6,2026352035,'Ike','Basile','eu.erat@google.net','Ap #841-2875 Aliquet. Avenue','Idaho Falls',82707,'Missouri','United States',7),(7,2320127002,'Giselbert','Androsik','eu.sem.pellentesque@protonmail.edu','6915 Nunc Ave','Overland Park',31625,'Kentucky','United States',8),(8,2347167796,'Kaylil','Drissell','nunc.sit.amet@yahoo.couk','352-5731 Nibh Street','College',72308,'Georgia','United States',9),(9,2873212765,'Fletcher','Kunz','penatibus.et@yahoo.edu','Ap #508-492 Donec Rd.','Norman',21515,'Illinois','United States',10),(10,3372868164,'Dodi','Spooner','nunc.sed@hotmail.org','Ap #210-7583 Sed Ave','North Las Vegas',79015,'Connecticut','United States',11),(11,3977333714,'Matti','Collick','aliquam.nec.enim@outlook.net','5062 Tellus Av.','Salt Lake City',45663,'Wyoming','United States',12),(12,4020332650,'Ralf','Demangeon','lorem.ac@icloud.org','729-1864 Egestas Road','Missoula',62357,'Texas','United States',13),(13,4057192912,'Auberon','Bowcher','magnis.dis.parturient@protonmail.net','518-4320 Viverra. Av.','Nashville',42252,'Washington','United States',14),(14,4319703577,'Jania','Abeles','enim.suspendisse@hotmail.ca','Ap #958-2270 Erat, Av.','Toledo',56832,'Arkansas','United States',15),(15,4388161847,'Alyce','Waplington','aliquam.fringilla@hotmail.edu','531-5165 Ac Avenue','Des Moines',85192,'Pennsylvania','United States',16),(16,4445114986,'Amelie','Mattioni','quam@hotmail.net','9318 Fringilla Rd.','Missoula',92505,'Minnesota','United States',17),(17,4558609924,'Owen','Tomaszkiewicz','nunc.ac@outlook.couk','8038 Morbi St.','Fairbanks',81714,'Alaska','United States',18),(18,4702921684,'Margaux','Sallnow','proin.vel@yahoo.net','Ap #680-6234 Non, Ave','Grand Rapids',32027,'California','United States',19),(19,5553957443,'Constance','Bygraves','quisque@protonmail.com','514-2858 Nulla Avenue','Columbia',73856,'Iowa','United States',20),(20,5577150313,'Winnah','Eilhertsen','aliquam.auctor.velit@hotmail.edu','Ap #822-273 Mattis Av.','Las Vegas',58315,'Oregon','United States',21),(21,6117666160,'Catharina','Faragher','cum@icloud.ca','Ap #186-1960 Molestie Rd.','Des Moines',78368,'Wyoming','United States',22),(22,6290855005,'Burg','Fotitt','eu.nulla.at@outlook.ca','Ap #545-9246 Mi Rd.','New Orleans',17157,'Hawaii','United States',23),(23,6775888955,'Brant','Blackaller','nascetur.ridiculus.mus@icloud.com','P.O. Box 481, 6958 Ut Rd.','Wilmington',36426,'Hawaii','United States',24),(24,6962181067,'Astrix','Stener','lacinia.sed@outlook.com','P.O. Box 301, 4613 Orci Rd.','Tampa',53381,'Alaska','United States',25),(25,7007744171,'Chad','Huxter','praesent.interdum@google.com','Ap #941-5194 Cras Street','Gary',77562,'Idaho','United States',26),(26,7086361926,'Gretna','Kyne','placerat.cras@protonmail.edu','1559 Diam Av.','Joliet',27326,'Massachusetts','United States',27),(27,8053475328,'Ivory','Tynnan','integer.tincidunt@hotmail.net','P.O. Box 763, 100 Massa. Av.','Gresham',76813,'California','United States',28),(28,8253242879,'Willey','O\'Hear','dapibus.ligula@google.net','P.O. Box 808, 2752 Accumsan Avenue','Columbus',92295,'Alabama','United States',29),(29,8378563200,'Tulley','Dickie','id.magna.et@hotmail.couk','775-7761 Magna. St.','Augusta',82410,'Louisiana','United States',30),(30,8583815059,'Brigg','Tabourel','sociis.natoque@outlook.couk','1145 Sit Av.','Salem',48848,'Kansas','United States',31),(31,8792009665,'Normand','Eakens','erat.semper@outlook.com','755-6569 Sit Ave','Gary',76616,'Oklahoma','United States',32),(32,8877689391,'Mario','Matskevich','libero.at@aol.edu','Ap #946-4554 Aliquam Rd.','Covington',53520,'Vermont','United States',33);
/*!40000 ALTER TABLE `locationinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-12 14:47:16
