-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: dsba_6160_project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `personalinfo`
--

DROP TABLE IF EXISTS `personalinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personalinfo` (
  `index` bigint DEFAULT NULL,
  `id` bigint DEFAULT NULL,
  `Title` text,
  `first_name` text,
  `last_name` text,
  `race/ethnicity` text,
  `gender` text,
  `College` text,
  `Job` text,
  `Comapny` text,
  `Department` text,
  `LocationId` bigint DEFAULT NULL,
  KEY `ix_personalinfo_index` (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personalinfo`
--

LOCK TABLES `personalinfo` WRITE;
/*!40000 ALTER TABLE `personalinfo` DISABLE KEYS */;
INSERT INTO `personalinfo` VALUES (0,1503960366,'Honorable','Brittne','Di Bernardo','Nicaraguan','Genderqueer','Universidad Nacional de Tumbes','Administrative Assistant IV','Kare','Research and Development',1),(1,1624580081,'Mr','Idalia','Sweedland','South American','Female','Pontificia Università della Santa Croce','Assistant Media Planner','Ailane','Training',2),(2,1644430081,'Mrs','Katha','Martinho','Delaware','Female','Kingston University','VP Quality Control','Jatri','Product Management',3),(3,1844505072,'Rev','Brittan','Rookwell','Cherokee','Female','Indian Institute of Technology, Bombay','Account Executive','Mynte','Legal',4),(4,1927972279,'Rev','Kristofor','Jurgensen','Native Hawaiian and Other Pacific Islander (NHPI)','Male','Kabul Health Sciences Institute','Geologist IV','Edgeify','Product Management',5),(5,2022484408,'Mr','Arlette','Fitch','Paraguayan','Female','Université Pierre et Marie Curie (Paris VI)','Geologist III','Dynabox','Research and Development',6),(6,2026352035,'Ms','Ike','Basile','Bangladeshi','Male','Music Academy \"Karol Lipinski\" in Wroclaw','Librarian','Browsetype','Engineering',7),(7,2320127002,'Mrs','Giselbert','Androsik','Crow','Male','University of Essex','VP Marketing','Tekfly','Business Development',8),(8,2347167796,'Ms','Kaylil','Drissell','Aleut','Female','Southwestern College Kansas','Database Administrator II','Mita','Training',9),(9,2873212765,'Mrs','Fletcher','Kunz','Taiwanese','Male','Batterjee Medical College','Recruiter','Skaboo','Accounting',10),(10,3372868164,'Ms','Dodi','Spooner','Chamorro','Female','Skidmore College','Registered Nurse','Yabox','Business Development',11),(11,3977333714,'Dr','Matti','Collick','Menominee','Female','New York Law School','Registered Nurse','Devbug','Training',12),(12,4020332650,'Dr','Ralf','Demangeon','Indonesian','Male','Coppin State College','Programmer Analyst II','Jaloo','Legal',13),(13,4057192912,'Mr','Auberon','Bowcher','Tohono O\'Odham','Genderfluid','Jahrom University of Medical Sciences','Civil Engineer','Agimba','Training',14),(14,4319703577,'Ms','Jania','Abeles','Hmong','Female','China Academy of Art','Structural Engineer','Leenti','Training',15),(15,4388161847,'Ms','Alyce','Waplington','Micronesian','Female','Maharishi Dayanand University, Rohtak (Haryana )','Media Manager IV','Tagfeed','Business Development',16),(16,4445114986,'Dr','Amelie','Mattioni','Osage','Female','Mimar Sinan University','Software Test Engineer IV','Zava','Services',17),(17,4558609924,'Dr','Owen','Tomaszkiewicz','Bangladeshi','Male','Manhattan School of Music','Analyst Programmer','Voolith','Human Resources',18),(18,4702921684,'Mrs','Margaux','Sallnow','Native Hawaiian and Other Pacific Islander (NHPI)','Female','Ukrainian Medical Stomatological Academy','Programmer Analyst III','Abata','Training',19),(19,5553957443,'Mrs','Constance','Bygraves','Pakistani','Female','Nivadhana University','Payment Adjustment Coordinator','Meembee','Marketing',20),(20,5577150313,'Honorable','Winnah','Eilhertsen','Bolivian','Female','Moscow State Technical University of Civil Aviation','Software Test Engineer III','Dynazzy','Marketing',21),(21,6117666160,'Dr','Catharina','Faragher','Guatemalan','Female','Groupe Sup de Co Montpellier','Professor','Quimm','Product Management',22),(22,6290855005,'Dr','Burg','Fotitt','Cree','Non-binary','Muscat College','VP Marketing','Kwideo','Marketing',23),(23,6775888955,'Mr','Brant','Blackaller','South American','Male','Tver State Medical Academy','Physical Therapy Assistant','Youopia','Engineering',24),(24,6962181067,'Ms','Astrix','Stener','Asian Indian','Polygender','Ecole Européen des Affaires','Senior Developer','Dabfeed','Product Management',25),(25,7007744171,'Ms','Chad','Huxter','Central American','Female','Bergische Universität Gesamthochschule Wuppertal','Geological Engineer','Zoovu','Legal',26),(26,7086361926,'Ms','Gretna','Kyne','Native Hawaiian','Female','Universidade Lusiada','Human Resources Assistant III','Twitterbeat','Marketing',27),(27,8053475328,'Mr','Ivory','Tynnan','Creek','Female','Concordia College, Moorhead','Senior Editor','Jayo','Training',28),(28,8253242879,'Rev','Willey','O\'Hear','Melanesian','Male','Universidad Católica Santo Toribio de Mogrovejo','Assistant Manager','LiveZ','Product Management',29),(29,8378563200,'Ms','Tulley','Dickie','Pima','Male','Bergische Universität Gesamthochschule Wuppertal','Internal Auditor','Oodoo','Research and Development',30),(30,8583815059,'Mrs','Brigg','Tabourel','Blackfeet','Male','Salisbury State University','Research Associate','Tazzy','Marketing',31),(31,8792009665,'Dr','Normand','Eakens','Honduran','Agender','Universidad Nacional Experimental \"Simón Rodriguez\"','Physical Therapy Assistant','Jaloo','Training',32),(32,8877689391,'Honorable','Mario','Matskevich','Latin American Indian','Non-binary','Open University Malaysia','Safety Technician III','Trunyx','Business Development',33);
/*!40000 ALTER TABLE `personalinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-12 14:47:16
